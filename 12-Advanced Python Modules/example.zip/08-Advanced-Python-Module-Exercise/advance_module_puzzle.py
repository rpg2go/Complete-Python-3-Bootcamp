import shutil

if __name__ = "__main__":
    zip_file = "unzip_me_for_instructions.zip"
    zip_folder = "extracted_contect"

    shutil.unpack_archive(zip_file, zip_folder, format="zip")



